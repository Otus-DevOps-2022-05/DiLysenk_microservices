kubeadm init --apiserver-cert-extra-sans=62.84.119.140 --apiserver-advertise-address=0.0.0.0 --control-plane-endpoint=62.84.119.140 --pod-network-cidr=10.244.0.0/16
